(function(){
    var myCanvas;

    var selectedTool = document.getElementById('selectedTool').value;

    var image = document.getElementById('imgPreview');
    var newFileOptionsWrapper = document.getElementById('new_options');
    var saveFileOptionsWrapper = document.getElementById('save_options');


    /**
     * Canvas Object
     */
    var canvas = {
        canvas: document.createElement('canvas'),
        name: '',
        type: 'png',
        drawing: false,
        bgColor: '#ffffff',
        fgColor: '#000000',
        tool: 'pencil',
        strokeWidth: 1,
        sx: 0,
        sy: 0,
        ex: 0,
        ey: 0,
        start: function(cWidth, cHeight){
            this.canvas.width = cWidth;
            this.canvas.height = cHeight;
            this.canvas.id = 'myCanvas';
            this.context = this.canvas.getContext('2d');
            document.getElementById('canvasWrapper').appendChild(this.canvas);
            return this.canvas;
        },
        fillBackground: function(){
            ctx = this.context;
            ctx.fillStyle = this.bgColor;
            ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        },
        drawMoveTo: function(){
            ctx = this.context;
            if (this.tool == 'pencil') {
                ctx.lineWidth = this.strokeWidth;
                ctx.strokeStyle = this.fgColor;
            } else if (this.tool == 'erase') {
                ctx.lineWidth = 10;
                ctx.strokeStyle = this.bgColor;
            }
            ctx.beginPath();
            ctx.moveTo(this.sx, this.sy);
        },
        drawPath: function(x, y){
            ctx = this.context;
            ctx.lineTo(x, y);
            ctx.stroke();
        },
        drawLine: function(){
            ctx = this.context;
            ctx.beginPath();
            ctx.lineWidth = this.strokeWidth;
            ctx.strokeStyle = this.fgColor;
            ctx.moveTo(this.sx, this.sy);
            ctx.lineTo(this.ex, this.ey);
            ctx.stroke();
        },
        drawCircle: function(){
            x1 = this.sx;
            y1 = this.sy;
            x2 = this.ex;
            y2 = this.ey;
            ctx = this.context;
            ctx.beginPath();
            ctx.lineWidth = this.strokeWidth;
            ctx.strokeStyle = this.fgColor;
            distance = Math.sqrt( ((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)) );
            ctx.arc(x1, y1, distance, 0, 2 * Math.PI);
            ctx.stroke();
        },
        drawBox: function(){
            x1 = this.sx;
            y1 = this.sy;
            x2 = this.ex;
            y2 = this.ey;
            ctx = this.context;
            ctx.beginPath();
            ctx.lineWidth = this.strokeWidth;
            ctx.strokeStyle = this.fgColor;
            ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
            ctx.stroke();
        },
        drawStroke: function(){
            ctx = this.context;
            ctx.stroke();
        },
        drawPic: function(image){
            var x = (image.width - this.canvas.width) / 2;
            var y = (image.height - this.canvas.height) / 2;
            ctx = this.context;
            ctx.drawImage(image, -x, -y);
        },
        saveCanvas: function(){
            ctx = this.context;
            console.log('saved');
            ctx.save();
        },
        restoreCanvas: function(){
            ctx = this.context;
            console.log('restored');
            ctx.restore();
        },
        finalImage: function(){
            return this.canvas.toDataURL('image/png');
        }
    }
    

    /**
     * Creating New Canvas.
     */
    var createFileForm = document.getElementById('createCanvasOptions');
    createFileForm.addEventListener('submit', function(e){
        e.preventDefault();
        var form = e.target;
        var formData = [];

        for(let i = 0; i < form.elements.length; i++){
            let formField = form.elements[i];
            if(formField.name === 'bg_type'){
                (formField.checked) ? formData[formField.name] = formField.value : '';
            } else {
                formData[formField.name] = formField.value;
            }
        }

        document.getElementById('img_name').innerHTML = ' | ' + formData.imageName;
        myCanvas = canvas.start(formData.cWidth, formData.cHeight);
        canvas.fillBackground();
        canvas.tool = selectedTool;
        canvas.name = formData.imageName;
        newFileOptionsWrapper.style.display = 'none';

        document.getElementById(selectedTool).classList.add('activeBtn');

        myCanvas.addEventListener('mousedown', function(e){
            canvas.drawing = true;
            canvas.sx = e.offsetX;
            canvas.sy = e.offsetY;
            if (canvas.tool == 'pencil' || canvas.tool == 'erase') {
                canvas.drawMoveTo();
            }
        });

        myCanvas.addEventListener('mousemove', function(e){
            if(canvas.drawing){
                if(canvas.tool == 'pencil' || canvas.tool == 'erase'){
                    canvas.drawPath(e.offsetX, e.offsetY);
                }
            }
        });

        myCanvas.addEventListener('mouseup', function(e){
            canvas.drawing = false;
            canvas.ex = e.offsetX;
            canvas.ey = e.offsetY;
            if (canvas.tool == 'line'){
                canvas.drawLine();
            } else if (canvas.tool == 'circle') {
                canvas.drawCircle();
            } else if (canvas.tool == 'box') {
                canvas.drawBox();
            } else if (canvas.tool == 'pencil' || canvas.tool == 'erase') {
                canvas.drawStroke();
            }
        });

        document.getElementById('imageType').addEventListener('change', function(e){
            canvas.type = e.target.value;
        }); 
        
        document.getElementById('getImage').addEventListener('click', function(){
            var imgLink = document.createElement('a');
            imgLink.innerHTML = 'Download Image';
            imgLink.href = myCanvas.toDataURL('image/' + canvas.type);
            imgLink.download = canvas.name + '.' + canvas.type;
            imgLink.click();
        
            saveFileOptionsWrapper.style.display = 'none';
        });

        
        window.addEventListener('keydown', function(e){
            var key = e.which;
            if(key == 83){
                canvas.saveCanvas();
            } else if (key == 90){
                canvas.restoreCanvas();
            }
        });
    });

    
    /**
     * Selecting Tool
     */
    document.getElementById('tool_bar').addEventListener('click', function( eve ){
        var toolBtns = document.querySelectorAll('button.btn-tool');
        toolBtns.forEach(function( ele ){
            ele.classList.remove('activeBtn');
        });
        if ( eve.target && eve.target.nodeName == 'BUTTON' ){
            canvas.tool = eve.target.id;
            eve.target.classList.add('activeBtn');
        } else if (eve.target && eve.target.nodeName == 'I'){
            canvas.tool = eve.target.parentElement.id;
            eve.target.parentElement.classList.add('activeBtn');
        }
    }, false);


    /**
     * Choosing Background and Foreground colors
     */
    document.getElementById('fgColor').addEventListener('change', function(e){
        canvas.fgColor = e.target.value;
    });
    document.getElementById('bgColor').addEventListener('change', function(e){
        canvas.bgColor = e.target.value;
    });
    document.getElementById('strokeWidth').addEventListener('change', function(e){
        canvas.strokeWidth = e.target.value;
    });
    document.getElementById('fillColor').addEventListener('click', function(){
        canvas.fillBackground(bgColor);
    });


    document.getElementById('new_file').addEventListener('click', function(){
        newFileOptionsWrapper.style.display = 'block';
    });
    document.getElementById('save_file').addEventListener('click', function(){
        image.src = canvas.finalImage();
        document.getElementById('imageName').value = canvas.name;
        saveFileOptionsWrapper.style.display = 'block';
    });
    
    
    document.getElementById('loadImage').addEventListener('change', function(event){
        var input = event.target;
        var dataURL;
        var reader = new FileReader();
    
        reader.onload = function(){
            dataURL = reader.result;
            
            var image = new Image();
            image.src = dataURL;
            canvas.drawPic(image);
        }
        reader.readAsDataURL(input.files[0]);
    });

}());

var closeModel = function( eve ){
    document.getElementById(eve).style.display = 'none';
}

