$(document).ready(function(){
    var slideWrapperWidth = 0;
    var numberOfSlide = 0;
    var slideWidth = 0;
    var viewWidth = 400;
    var slides = $('.slide-item');
    var i = 0;

    slideWrapperWidth = $('#slideWrapper').width();    
    numberOfSlide = slides.length;
    slideWidth = (slideWrapperWidth - viewWidth) / numberOfSlide;

    $('.slide-item').css('width', slideWidth + 'px');
    $('.slide-item:first').css('width', viewWidth + slideWidth + 'px');

    $('.slide-item').on('mouseenter', function(){
        $('.slide-item').animate({width: slideWidth + 'px'}, { duration: 300, queue: false });
        $(this).animate({width: viewWidth + slideWidth + 'px'}, { duration: 300, queue: false });
    });
});